/**
 * the main class.
 *
 * */
public class GraphicsMain {
    /**
     * main method.
     * @param args not used
     * */
    public static void main(String[] args) {
        Model model = new Model();
        Delegate delegate = new Delegate(model);
    }
}
